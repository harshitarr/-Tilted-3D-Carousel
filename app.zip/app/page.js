import BannerSlider from "../components/BannerSlider";

export default function HomePage() {
  return <BannerSlider />;
}

